import React from 'react';

import localTasks from './local-tasks.twig';

import localTasksData from './local-tasks.yml';

import './local-tasks';

/**
 * Storybook Definition.
 */
export default { title: 'Molecules/LocalTasks' };

export const LocalTasks = () => (
  <div dangerouslySetInnerHTML={{ __html: localTasks(localTasksData) }} />
);
